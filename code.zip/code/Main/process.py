import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.feature_extraction.text import TfidfVectorizer
from Proposed import DFFNN

def kumar_hassebrook(P,Q):
    P = np.transpose(P)
    kh = (np.sum(P * Q) / (np.sum(np.square(P))) + np.sum(np.square(Q)) - np.sum(P * Q))
    return kh
def Czekanowski_similarity(P,Q):
    P = np.transpose(P)
    c = np.sum(P - Q) / (np.sum(P + Q))
    return c
def TF_IDF(sentence):
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(sentence)
    x = X.toarray()
    x = np.mean(x, axis=1)
    return x

# n-grams features
def generate_N_grams(text):
    words = text.split()
    output = []
    WordsToCombine = 2
    for i in range(len(words) - WordsToCombine + 1):
        output.extend(words[i:i + WordsToCombine])
    WordsToCombine = 3
    for j in range(len(words) - WordsToCombine + 1):
        output.extend(words[j:j + WordsToCombine])
    return output

def norm(Data):
    min_max_scaler = preprocessing.MinMaxScaler()
    data_minmax = min_max_scaler.fit_transform(Data)
    return data_minmax

Acc, Tpr, Tnr = [], [], []
Dataset = pd.read_csv(r'data,csv')
data = np.array(Dataset)[:,0]
feat = []
#----------------------feature extraction-------------------
for i in range(len(data)):
    n_grams = generate_N_grams(data[i])         # 2 gram and 3 gram
    tfidf = TF_IDF(n_grams)                     # TF-IDF
    feat.append(tfidf)
#----------------------data normalization-------------------
feat = np.array(feat)
nor = norm(feat)
#---------------------feature selection--------------------
KH = kumar_hassebrook(nor,nor[:,-1])            # Kumar Hassebrook
C = Czekanowski_similarity(nor,nor[:,-1])       # Czekanowski Similarity
a1,a2 = 0.2,0.7
hy_sim = int(abs(a1 * KH) + (a2 * C))
feat_sel = nor[:,:hy_sim]

#-----------------------Proposed-----------------------------

DFFNN.dffnn(feat_sel,nor[:,-1],Acc, Tpr, Tnr)
