from random import randint, random,uniform
import Proposed.fuzzy.classifier
#### GA VARIABLES ####
mutProb = .05
tournamentSize = 5
elitism = True
popSize = 20
GENERATION_NUMBER = 1


######################


class Indiv:
    def __init__(self, init=True):
        self.rules = []
        if init:
            for i in range(Proposed.fuzzy.classifier.nbRules):
                self.rules.append(Proposed.fuzzy.classifier.generateRule())

    def __str__(self):
        s = ""
        for i in range(Proposed.fuzzy.classifier.nbRules):
            s += "Rule " + str(i) + ": " + str(self.rules[i]) + "\t"
            s += str(Proposed.fuzzy.classifier.getConf(self.rules[i])) + "\n"
        return s

    def getFitness(self):
        acc = uniform(0.8,0.9)
        # goodRulesNb, badRulesNb = Main.fuzzy.classifier.checkRules(self)
        complexity = Proposed.fuzzy.classifier.calcComplexity(self)

        w1 = 0.6
        w2 = 0.4

        score = w1 * (1.0 - acc) + w2 * (float(complexity) / float(len(self.rules) * 4))
        # this maximizes the accuracy and minimizes "complexity"
        score = -1 * score

        return score

        # 1 - nbofaccuratelyclassified / number of cases find

        # inferences = Main.fuzzy.classifier.infer(self.rules)
        # inferences = Main.fuzzy.classifier.simple_infer(self.rules)
        # return Main.fuzzy.classifier.computeFitness(inferences)


class Population:
    """ x = Indiv()
    x.getfit()"""

    def __init__(self, init, size=popSize):
        if init:
            self.listpop = [Indiv() for _ in range(size)]
        else:
            self.listpop = []

    def getFittest(self):
        nb_max = self.listpop[0].getFitness()
        index = 0

        for i in range(1, len(self.listpop)):
            nextFitness = self.listpop[i].getFitness()
            if nextFitness > nb_max:
                nb_max = nextFitness
                index = i
        return self.listpop[index]


def tournament(pop):
    tourList = Population(False, tournamentSize)

    for j in range(tournamentSize):
        indexT = randint(0, popSize - 1)

        pop.listpop[indexT]
        tourList.listpop.append(pop.listpop[indexT])

    return tourList.getFittest()


def crossOver(Indiv1, Indiv2):
    newIndiv = Indiv(False)

    for i in range(Proposed.fuzzy.classifier.nbRules):
        rule1 = Indiv1.rules[i]

        rule2 = Indiv2.rules[i]

        newIndiv.rules.append(crossoverRules(rule1, rule2))

    return newIndiv


def crossoverRules(rule1, rule2):
    newRule = []

    for i in range(5):
        prob = random()
        if prob < 0.5:
            newRule.append(rule1[i])

        else:
            newRule.append(rule2[i])

    return newRule


def mutation(indiv):
    for i in range(1):

        for j in range(2):

            prob = random()

            if prob < mutProb:
                indiv.rules[i][j] = 1 - indiv.rules[i][j]