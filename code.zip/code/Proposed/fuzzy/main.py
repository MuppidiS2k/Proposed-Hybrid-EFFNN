import numpy as np

import Proposed.fuzzy.classifier
from Proposed.fuzzy.GA import *
from sklearn.model_selection import train_test_split
def main(data,target,tr):
    X_train, X_test, y_train, y_test = train_test_split(data, target, train_size=tr, random_state=42)

    pop = Population(True)

    for i in range(GENERATION_NUMBER):

        newpop = Population(False)
        # print("Generation number : "+str(i))

        for j in range(popSize):

            parent1 = tournament(pop)
            parent2 = tournament(pop)

            child = crossOver(parent1,parent2)
            newpop.listpop.append(child)

        for j in range(popSize):
            mutation(newpop.listpop[j])

        pop = newpop

        thisFittest = pop.getFittest()
        #print("Fittest accuracy : " + str(classifier.getAccuracy(thisFittest)))
        #print(thisFittest)
    rules = Proposed.fuzzy.classifier.generateRule()
    # print(Main.fuzzy.classifier.calcComplexity(thisFittest))
    pred = Proposed.fuzzy.classifier.getAccuracy(rules,X_train,X_test,y_train,y_test)

    return np.array(pred)