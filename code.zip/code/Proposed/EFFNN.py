import numpy as np
import tensorflow as tf
from Proposed.fuzzy import main
TF_USE_LEGACY_KERAS=True
def process(Data,Label,l1):
    # -------------------------------calculating weight------------------------------

    opt = tf.keras.optimizers.RMSprop(learning_rate=0.001)  #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(1)])
    m.compile(opt, loss='mse')
    m.fit(Data, Label)  # Training.
    w = m.get_weights()[0]

    # -----------------------------------------------------------
    tran = np.transpose(Data)

    y=[]

    for j in range(tran.shape[0]):
        z = []
        for k in range(tran.shape[1]):
            z.append(tran[j][k] * w[j][0])
        y.append(z)
    y = np.transpose(y)

    l1 = np.resize(l1,(y.shape[0],y.shape[1]))

    h = 0.2
    l2 = h * y + (1 / 2) * h * l1
    # -----------------------------------------fusion-fuzzy-----------------------------------------------

    fuz = main.main(Data,Label,0.9)
    fuz = np.resize(fuz,(len(l2),1))
    return fuz