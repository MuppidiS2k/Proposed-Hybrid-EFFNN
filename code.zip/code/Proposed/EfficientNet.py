import numpy as np
from keras.optimizers import Adam
import efficientnet.keras as efn
from keras.utils import to_categorical
from sklearn.model_selection import train_test_split
def classify(x,y):
    # y=np.resize(y,(x.shape[0],))
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.7, random_state=0)
    batch_size = 32
    epochs = 5  # Epoch is varried by changing the iteration value
    data_augmentation = True
    num_classes = len(np.unique(y_train))
    loss = 'categorical_crossentropy'
    learning = 0.0001
    model = efn.EfficientNetB0(weights=None, include_top=False, classes=107)
    optimizer = Adam(learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-08)
    model.compile(optimizer=optimizer, loss=loss, metrics=['accuracy'])
    # model.summary()
    aa = x_train.shape
    y_train1 = to_categorical(y_train)
    x_train_n1 = np.resize(x_train, (aa[0], 8, 8, 3))
    y_train_n1 = np.resize(y_train1, (aa[0], 1, 1, 1280))
    x_test = np.resize(x_test,(aa[0],32,32,3))
    model.fit(x_train_n1, y_train_n1, batch_size=batch_size, epochs=epochs)
    pred=model.predict(x_test)
    return pred
